import random
import json
import pickle
import numpy as np
import nltk 
from nltk.stem import WordNetLemmatizer
import speech_recognition as sr
import pyttsx3