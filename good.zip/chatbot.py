import random
import json
import pickle
import numpy as np
import nltk 
from nltk.stem import WordNetLemmatizer
import speech_recognition as sr
import pyttsx3
import pyaudio
import wave

from tensorflow.keras.models import load_model

lemmatizer = WordNetLemmatizer()
intents = json.loads(open('intents.json').read())

words = pickle.load(open('words.pkl', 'rb'))
classes = pickle.load(open('classes.pkl', 'rb'))
model = load_model('chatbot_model.h5')

# Initialize the SpeechRecognition recognizer
recognizer = sr.Recognizer()

# Initialize the pyttsx3 text-to-speech engine
engine = pyttsx3.init()

def clean_up_sentence(sentence):
    sentence_words = nltk.word_tokenize(sentence)
    sentence_words = [lemmatizer.lemmatize(word) for word in sentence_words]
    return sentence_words

def bag_of_words(sentence):
    sentence_words = clean_up_sentence(sentence)
    bag = [0] * len(words)
    for w in sentence_words:
        for i, word in enumerate(words):
            if word == w:
                bag[i] = 1
    #print(np.array(bag))
    return np.array(bag)

def predict_class(sentence):
    bow = bag_of_words(sentence)
    res = model.predict(np.array([bow]))[0]
    ERROR_THRESHOLD = 0.25
    results = [[i, r] for i, r in enumerate(res) if r > ERROR_THRESHOLD]
    results.sort(key=lambda x: x[1], reverse=True)
    return_list = []
    for r in results:
        return_list.append({'intents': classes[r[0]], 'probability': str(r[1])})
    return return_list

def get_response(intents_list, intents_json):
    tag = intents_list[0]['intents']
    list_of_intents = intents_json['intents']
    for i in list_of_intents:
        if i['tags'] == tag:
            result = random.choice(i['responses'])
            break
    return result


def record_audio(filename, duration):
    p = pyaudio.PyAudio()

    stream = p.open(format=pyaudio.paInt16,
                    channels=1,
                    rate=44100,
                    input=True,
                    frames_per_buffer=1024)

    #print("Recording...")
    print("Speak something:")

    frames = []

    for i in range(0, int(44100 / 1024 * duration)):
        data = stream.read(1024)
        frames.append(data)

    #print("Finished recording.")

    stream.stop_stream()
    stream.close()
    p.terminate()

    wf = wave.open(filename, 'wb')
    wf.setnchannels(1)
    wf.setsampwidth(pyaudio.PyAudio().get_sample_size(pyaudio.paInt16))
    wf.setframerate(44100)
    wf.writeframes(b''.join(frames))
    wf.close()

def recognize_audio(filename):
    recognizer = sr.Recognizer()
    with sr.AudioFile(filename) as source:
        audio = recognizer.record(source)
        user_input = recognizer.recognize_google(audio)
        return user_input


print("GO! Bot is running")

while True:
    print("end")
    try:
        # Listen for speech input
        audio_file = "audio.wav"
        record_duration = 10  # Record for 5 seconds (adjust as needed)

        record_audio(audio_file, record_duration)
        

        # Recognize speech input
        #user_input = recognizer.recognize_google(audio)
        user_input = recognize_audio(audio_file)
        print("You said:", user_input)
        if user_input == "Break":
            break

        # Get chatbot response
        ints = predict_class(user_input)
        
        # Debug: Print predicted intents and their probabilities
        for intent in ints:
            print(f"Predicted Intent: {intent['intents']} (Probability: {intent['probability']})")

        chatbot_response = get_response(ints, intents)

        # Output chatbot response as speech
        engine.say(chatbot_response)
        engine.runAndWait()

    except sr.UnknownValueError:
        print("Sorry, I couldn't understand what you said.")
    except sr.RequestError as e:
        print(f"Could not request results; {e}")
    except Exception as e:
        print(f"An error occurred: {e}")